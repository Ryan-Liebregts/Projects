#ifndef LINKEDLIST_H
#define LINKEDLIST_H

typedef struct LinkedListNode
{
    void *data;
    struct LinkedListNode* prev;
    struct LinkedListNode* next;
} LinkedListNode;

typedef struct
{
    LinkedListNode* head;
    LinkedListNode* tail;
    int count;
} LinkedList;

typedef struct
{
    int x;
    int y;
    char or;
} Position;

typedef void (*listFunc)(void* data);

LinkedList* createLinkedList();
void insertFirst(LinkedList* list, void* entry);
void insertLast(LinkedList* list, void* entry);
void* removeFirst(LinkedList* list);
void* removeLast(LinkedList* list);

void freeLinkedList(LinkedList* list, listFunc funcPtr);
void printLinkedList(LinkedList* list, listFunc funcPtr);  

void printList(void* entry);
void freeList(void* data);

#endif