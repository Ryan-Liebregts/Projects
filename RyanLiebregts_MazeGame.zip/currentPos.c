/*
 * File: currentPos.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: Searches the 2D malloc array for the specified element and returns its position
 */
 
#include<stdio.h>
#include<stdlib.h>

#include "currentPos.h"

/*
 * Function: currentPos
 * Input: char **p, int r, int c, char coord, char type
 * Output: int pos
 * Purpose: Searches the map for the specified element and returns its x/y coord in the map
 */
int currentPos(char **p, int r, int c, char coord, char type)
{
    int i, j, pos;

    for (i = 0; i < r; ++i) 
    {
		for (j = 0; j < c; ++j) 
        {
            /* Searches for (P)layer */
            if(type == 'P')
            {
                if(p[i][j] == '^' || p[i][j] == '<' || p[i][j] == '>' || p[i][j] == 'v')
                {
                    if(coord == 'x')
                    {
                        /* Retrieves x coord */
                        pos = i;
                    }
                    else if(coord == 'y')
                    {
                        /* Retrieves y coord */
                        pos = j;
                    }
                }
            }
            /* Searches for (G)oal */
            else if(type == 'G')
            {
                if(p[i][j] == 'x')
                {
                    if(coord == 'x')
                    {
                        pos = i;
                    }
                    else if(coord == 'y')
                    {
                        pos = j;
                    }
                }
            }
            /* Searches for (E)nemy */
            else if(type == 'E')
            {
                if(p[i][j] == '~')
                {
                    if(coord == 'x')
                    {
                        pos = i;
                    }
                    else if(coord == 'y')
                    {
                        pos = j;
                    }
                }
            }
        }
    }
    return pos;
}