#ifndef CURRENTPOS_H
#define CURRENTPOS_H

int currentPos(char **map, int r, int c, char coord, char type);

#endif