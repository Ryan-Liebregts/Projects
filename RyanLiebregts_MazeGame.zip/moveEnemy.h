#ifndef MOVEENEMY_H
#define MOVEENEMY_H

#include "LinkedList.h"

void moveEnemy(char** map, int r, int c, int enemyPosX, int enemyPosY, char pos, LinkedList* enemyList);

#endif