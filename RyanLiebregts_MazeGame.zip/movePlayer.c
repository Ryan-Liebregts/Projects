/*
 * File: movePlayer.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: Allows for the player movement in that map 
 */

#include<stdio.h>
#include<stdlib.h>

#include "movePlayer.h"
#include "currentPos.h"
#include "LinkedList.h"

/* Note, x and y are inverted such that the
    x represents the vertical axis and,
    y represents the horizontal axis */


/*
 * Function: movePlayer
 * Input: char** map, int r, int c, int posX, int posY, char pos, LinkedList* playerList
 * Output: None
 * Purpose: Moves the player based on user input 
 */
void movePlayer(char** map, int r, int c, int posX, int posY, char pos, LinkedList* playerList)
{
    LinkedListNode* node;
    char or;
    /* Note, x and y are inverted such that the
        x represents the vertical axis and,
        y represents the horizontal axis */

    /* Deletes player from current position */
    map[posX][posY] = ' ';

    /* Moves player form current position */
    if(pos == 'w') /* Moves up */
    {
        if(map[posX-1][posY] == 'o' || map[posX-1][posY] == '-' || map[posX-1][posY] == '~')
        {
            /* If walls/borders do not move */
            map[posX][posY] = '^';
        }
        else
        {
            /* Otherwise move forward */
            map[posX-1][posY] = '^';
        }
    }
    else if(pos == 's') /* Moves down */
    {
        if(map[posX+1][posY] == 'o' || map[posX+1][posY] == '-' || map[posX+1][posY] == '~')
        {
            /* If walls/borders do not move */
            map[posX][posY] = 'v';
        }
        else
        {
            /* Otherwise move down */
            map[posX+1][posY] = 'v';
        }
    }
    else if(pos == 'a') /* Moves left */
    {
        if(map[posX][posY-1] == 'o' || map[posX][posY-1] == '|' || map[posX][posY-1] == '~')
        {
            /* If walls/borders do not move */
            map[posX][posY] = '<';
        }
        else
        {
            /* Otherwise move left */
            map[posX][posY-1] = '<';
        }
    }
    else if(pos == 'd') /* Moves right */
    {
        if(map[posX][posY+1] == 'o' || map[posX][posY+1] == '|' || map[posX][posY+1] == '~')
        {
            /* If walls/borders do not move */
            map[posX][posY] = '>';
        }
        else
        {
            /* Otherwise move right */
            map[posX][posY+1] = '>';
        }
    }
    else if(pos == 'u') /* Undo */
    {     
        /* Gets the location of the last move via the linked list */
        node = (playerList -> tail) -> prev;
        
        /* Allocates the previous location to the next movement */
        
        posX = ((Position*)(node -> data)) -> x; /* X-coordinate */
        posY = ((Position*)(node -> data)) -> y; /* Y-coordinate */
        or = ((Position*)(node -> data)) -> or; /* Orientation of player */
        
        /* Updates map */
        map[posX][posY] = or;

    }
    else
    {
        /* Otherwise reset player to front position in same location */
        map[posX][posY] = '^';
    }
}