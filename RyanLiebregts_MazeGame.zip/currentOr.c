/*
 * File: currentOr.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: Searches the 2D malloc array for the orinetation of the player and returns it
 */
 
#include<stdio.h>
#include<stdlib.h>

#include "currentOr.h"

/*
 * Function: currentOr
 * Input: char **p, int r, int c
 * Output: char or
 * Purpose: Searches the map for the player and returns its current orientation
 */
char currentOr(char **p, int r, int c)
{
    int i, j, or;

    for (i = 0; i < r; ++i) 
    {
		for (j = 0; j < c; ++j) 
        {
            if(p[i][j] == '^')
            {
                or = '^'; /* Up */
            }
            else if(p[i][j] == 'v')
            {
                or = 'v'; /* Down */
            }
            else if(p[i][j] == '<')
            {
                or = '<'; /* Left */
            }
            else if(p[i][j] == '>')
            {
                or = '>'; /* Right */
            }
        }
    }
    return or;
}