#ifndef PRINTMAP_H
#define PRINTMAP_H

void printMap(char** map, int r, int c, int playerPosX, int playerPosY);

#endif