/**************************************************************************** 
*	Filename: LinkedList.c
*   Author: Ryan Liebregts
*	Student ID: 20158316
*	Purpose: Creates a Linked List
****************************************************************************/

#include<stdio.h>
#include<stdlib.h>

#include "LinkedList.h"

/*
 * Function: createLinkedList
 * Input:  None
 * Output: LinkedList*
 * Purpose: Creates new empty linked list and allocates memory
 */
LinkedList* createLinkedList()
{
    LinkedList* list = (LinkedList*)malloc(sizeof(LinkedList));

    list -> head = NULL; /* Assigns head to NULL */
    list -> tail = NULL; /* Assigns tail to NULL */
    list -> count = 0; /* Assigns count to 0 */

    return list;
}

/*
 * Function: insertFirst
 * Input:  LinkedList* list, void* entry
 * Output: None
 * Purpose: Adds a value to the head of the linked list
 */
void insertFirst(LinkedList* list, void* entry)
{
    /* Allocates memory for new node */
    LinkedListNode* newNode = (LinkedListNode*)malloc(sizeof(LinkedListNode));

    LinkedListNode* prevHead;

    /* Assigns the new node the specified data */
    newNode -> data = entry;
    newNode -> next = NULL;
    newNode -> prev = NULL;

    if(list -> head == NULL)
    {
        /* If list is empty, set head = tail = entry */
        list -> head = newNode;
        list -> tail = newNode;
    }
    else
    {
        /* Otherwise create a new head and assign entry */
        prevHead = list -> head;
        prevHead -> prev = newNode;
        newNode -> next = prevHead;
        list -> head = newNode;
    }
    list -> count += 1; /* Adds 1 to the count */
}

/*
 * Function: insertLast
 * Input:  LinkedList* list, void* entry
 * Output: None
 * Purpose: Adds a value to the tail of the linked list
 */
void insertLast(LinkedList* list, void* entry)
{
    /* Allocates memory for new node */
    LinkedListNode* newNode = (LinkedListNode*)malloc(sizeof(LinkedListNode));

    LinkedListNode* prevTail;

    /* Assigns the new node the specified data */
    newNode -> data = entry;
    newNode -> next = NULL;
    newNode -> prev = NULL;

    if(list -> head == NULL)
    {
        /* If list is empty, set head = tail = entry */
        list -> head = newNode;
        list -> tail = newNode;
    }
    else
    {
        /* Otherwise create a new tail and assign entry */
        prevTail = list -> tail;
        prevTail -> next = newNode;
        newNode -> prev = prevTail;
        list -> tail = newNode;
    }
    list -> count += 1; /* Adds 1 to the count */
}

/*
 * Function: removeFirst
 * Input:  LinkedList* list
 * Output: void* nodeData
 * Purpose: Removes the head of the linked list
 */
void* removeFirst(LinkedList* list)
{
    void* nodeData;

	LinkedListNode* prevHead;

	if(list -> count == 0)
	{
        /* If list is empty, set NULL */
		nodeData = NULL;
	}

	else if(list -> count == 1)
	{
        /* If list has one element, set head = tail = NULL */
		nodeData = (list -> head) -> data;
		prevHead = list -> head;

		list -> head = NULL;
		list -> tail = NULL;

        /* Frees allocated memory */
        free(nodeData);
		free(prevHead);
	}
	else
	{
		/* If list has more than one element left*/
		nodeData = (list -> head) -> data;
		prevHead = list -> head;

		list -> head = (list -> head) -> next;
		(list -> head) -> prev = NULL;
		
        /* Frees allocated memory */
        free(nodeData);
        free(prevHead);
	}
	list -> count -= 1;
	return nodeData;
}

/*
 * Function: removeLast
 * Input:  LinkedList* list
 * Output: void* nodeData
 * Purpose: Removes the tail of the linked list
 */
void* removeLast(LinkedList* list)
{
    void* nodeData;

	LinkedListNode* prevTail;

	if(list -> count == 0)
	{
        /* If list is empty, set NULL */
		nodeData = NULL;
	}

	else if(list -> count == 1)
	{
        /* If list has one element, set head = tail = NULL */
		nodeData = (list -> tail) -> data;
		prevTail = list -> tail;

		list -> head = NULL;
		list -> tail = NULL;

        /* Frees allocated memory */
		free(nodeData);
        free(prevTail);
        
	}
	else
	{
		/* If list has more than one element left*/
		nodeData = (list -> tail) -> data;
		prevTail = list -> tail;

		list -> tail = (list -> tail) -> prev;
		(list -> tail) -> next = NULL;
		
        /* Frees allocated memory */
        free(nodeData);
        free(prevTail);
	}
	list -> count -= 1;
	return nodeData;
}

/*
 * Function: freeLinkedList
 * Input:  LinkedList* list, listFunc funcPtr
 * Output: None
 * Purpose: Frees the linked list iteratively
 */
void freeLinkedList(LinkedList* list, listFunc funcPtr) 
{
    LinkedListNode *node;

    /* Begins at head */
    node = list -> head;
    while(node != NULL) 
    {
        /* Frees data iteratively */
        free(node -> data);
        free(node); 
        node = node -> next;
        list -> count -= 1;
    }
    free(list); /*Frees list */
}

/*
 * Function: freeLinkedList
 * Input:  LinkedList* list, listFunc funcPtr
 * Output: None
 * Purpose: Prints the linked list nodes iteratively
 */
void printLinkedList(LinkedList* list, listFunc funcPtr) 
{
    LinkedListNode *node;

    /* Begins at head */
    node = list -> head;
    if(list -> count == 0)
    {
        /* Empty list */
        printf("List is empty\n");
    }
    else
    {
        while(node != NULL) 
        {
            /* Non-empty list */
            printf("[%d,", ((Position*)(node -> data)) -> x);
            printf("%d]\n", ((Position*)(node -> data)) -> y);
            node = node -> next;
        }
    }
}

/* printList function pointer */
void printList(void* entry)
{
    printf("%p", entry);
}

/* freeList function pointer */
void freeList(void* data)
{
    free(data);
}
