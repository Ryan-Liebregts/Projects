/*
 * File: main.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: main function for the game to be played
 */

#include<stdio.h>
#include<stdlib.h>

#include "terminal.h"
#include "printMap.h"
#include "currentPos.h"
#include "currentOr.h"
#include "game.h"
#include "readFile.h"
#include "movePlayer.h"
#include "moveEnemy.h"
#include "LinkedList.h"

#define TRUE 0
#define FALSE !TRUE

int main(int argc, char* argv[])
{
    int i, done = FALSE, row, col;
    int playerPosX, playerPosY, goalPosX, goalPosY, enemyPosX, enemyPosY; 
    char ch, **map, *filename; 
    Data *metaD;
    Position *enemyPosStart, *playerPosStart, *enemyPosTemp, *playerPosTemp;
    LinkedList *playerList, *enemyList;
    FILE *file;
    
    if(argc < 2 || argc > 2)	
    {
        printf("Invalid number of input arguments\n");
	}
    else
    {
        /* Reads into the meta data file */
        filename = argv[1];
        file = fopen(filename, "r");
    
        /* Checks if meta data file exists and is openable */
        if(file == NULL)
        {
            perror("Error opening file");
        }
        else
        {
            system("clear");
            
            /* Reads file and returns an array of meta data */
            metaD = readFile(file);

            /* Allocates memory for Position Struct */
            playerPosStart = (Position*)malloc(sizeof(Position));
            enemyPosStart = (Position*)malloc(sizeof(Position));

            /* Creates linked lists for player and enemy */
            playerList = createLinkedList();
            enemyList = createLinkedList();

            /* Generates the map using meta data */
            row = metaD[0].row;
            col = metaD[0].col;

            map = createMap(metaD);

            /* Frees allocated memory for metaD */
            free(metaD);

            /* Locates the target */
            goalPosX = currentPos(map, row, col, 'x', 'G');
            goalPosY = currentPos(map, row, col, 'y', 'G');

            /* Locates the player */
            playerPosX = currentPos(map, row, col, 'x', 'P');
            playerPosY = currentPos(map, row, col, 'y', 'P');

            /* Assigns data to struct */
            playerPosStart -> x = playerPosX;
            playerPosStart -> y = playerPosY;
            playerPosStart -> or = currentOr(map, row, col);

            /* Inserts player position into list */
            insertFirst(playerList, (void*)playerPosStart);

            /* Locates the player */
            enemyPosX = currentPos(map, row, col, 'x', 'E');
            enemyPosY = currentPos(map, row, col, 'y', 'E');

            /* Assigns data to struct */
            enemyPosStart -> x = enemyPosX;
            enemyPosStart -> y = enemyPosY;

            /* Inserts enemy position into list */
            insertFirst(enemyList, (void*)enemyPosStart);

            /* Prints the map */
            printMap(map, row, col,playerPosX, playerPosY);

            while(done == FALSE)
            {
                /* Enables clear and reprint of map on every action */
                disableBuffer();
                scanf(" %c", &ch);
                enableBuffer();

                system("clear");

                /* Gets current player position */
                playerPosX = currentPos(map, row, col, 'x', 'P');
                playerPosY = currentPos(map, row, col, 'y', 'P');

                /* Gets current enemy position */
                enemyPosX = currentPos(map, row, col, 'x', 'E');
                enemyPosY = currentPos(map, row, col, 'y', 'E');

                /* Undo */
                if(ch == 'u' && playerList -> count != 1)
                {
                    /* Moves player to previous location */
                    movePlayer(map, row, col, playerPosX, playerPosY, ch, playerList);

                    /* Removes the previous location from linked list */
                    removeLast(playerList);

                    /* Moves enemy to previous location */
                    moveEnemy(map, row, col, enemyPosX, enemyPosY, ch, enemyList);

                    /* Removes the previous location from linked list */
                    removeLast(enemyList);

                    /* Updates map */
                    printMap(map, row, col, playerPosX, playerPosY);

                }
                /* If player is in starting position */
                else if(ch == 'u' && playerList -> count == 1)
                {
                    /* Change Nothing */
                    printMap(map, row, col, playerPosX, playerPosY);
                }
                else
                {
                    /* Allocates memory for Position Struct */
                    playerPosTemp = (Position*)malloc(sizeof(Position));
                    enemyPosTemp = (Position*)malloc(sizeof(Position));

                    /* Moves player according to user input WASD */
                    movePlayer(map, row, col, playerPosX, playerPosY, ch, playerList);

                    /* Updates player position */
                    playerPosX = currentPos(map, row, col, 'x', 'P');
                    playerPosY = currentPos(map, row, col, 'y', 'P');

                    /* Assigns data to struct */
                    playerPosTemp -> x = playerPosX;
                    playerPosTemp -> y = playerPosY;
                    playerPosTemp -> or = currentOr(map, row, col);

                    /* Inserts player position to the end of the list */
                    insertLast(playerList, (void*)playerPosTemp);

                    /* Moves enemy according to player position */
                    moveEnemy(map, row, col, enemyPosX, enemyPosY, ch, enemyList);

                    /* Updates enemy position */
                    enemyPosX = currentPos(map, row, col, 'x', 'E');
                    enemyPosY = currentPos(map, row, col, 'y', 'E'); 

                    /* Assigns data to struct */
                    enemyPosTemp -> x = enemyPosX;
                    enemyPosTemp -> y = enemyPosY; 

                    /* Inserts enemy position to the end of the list */
                    insertLast(enemyList, (void*)enemyPosTemp);        

                    /* Updates map */
                    printMap(map, row, col, playerPosX, playerPosY);
              
                    if(playerPosX == goalPosX && playerPosY == goalPosY)
                    {
                        /* If the goal is reached, end game */
                        printf("-YOU WIN!-\n");
                        done = TRUE;
                    }
                    else if(playerPosX == enemyPosX && playerPosY == enemyPosY)
                    {
                        /* If snake has the same location as player, end game */
                        printf("-YOU LOSE, TRY AGAIN!-\n");
                        done = TRUE;
                    }
                }
            }
            /* Free linked lists */
            freeLinkedList(playerList, &freeList);
            freeLinkedList(enemyList, &freeList);

            /* Free map before terminating program */
            for(i = 0; i < row; ++i) 
            {
                free(map[i]);
            }
            free(map);

            /* Close file */
            fclose(file);
        }
    }

    return 0;
}


