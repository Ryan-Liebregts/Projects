#ifndef MOVEPLAYER_H
#define MOVEPLAYER_H

#include "LinkedList.h"

void movePlayer(char** map, int r, int c, int posX, int posY, char pos, LinkedList* playerList);

#endif