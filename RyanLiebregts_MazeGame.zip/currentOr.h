#ifndef CURRENTOR_H
#define CURRENTOR_H

char currentOr(char **p, int r, int c);

#endif