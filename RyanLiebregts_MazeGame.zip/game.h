#ifndef GAME_H
#define GAME_H

#include "readFile.h"

char** createMap(Data* metaD);

#endif