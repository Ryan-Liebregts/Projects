/*
 * File: readFile.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: reads meta data from text file and assigns it to struct array
 */

#include<stdio.h>
#include<stdlib.h>

#include "readFile.h"

/*
 * Function: readFile
 * Input: FILE* file
 * Output: Data*
 * Purpose: Reads the meta data from an input file and assigns it to a struct array
 */
Data* readFile(FILE* file)
{
    int i, numElements, obj_row, obj_col, obj_code;
    Data *metaD;

    /* Determines the number of elements in the game */
    fscanf(file, "%d %d %d\n", &numElements, &obj_row, &obj_col);

    /* Allocates memory for Data Struct */
    metaD = (Data*)malloc((numElements + 1) * sizeof(Data)); 

    /* Assigns initial map data (first row) */
    metaD[0].row = obj_row;
    metaD[0].col = obj_col;
    metaD[0].code = numElements;

    i = 1;
    while(!feof(file))
    {
        fscanf(file, "%d %d %d\n", &obj_row, &obj_col, &obj_code);

        /* Assigns remaingin meta data */
        metaD[i].row = obj_row;
        metaD[i].col = obj_col;
        metaD[i].code = obj_code;

        i++;
    }

    return metaD;
}
