/*
 * File: printMap.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: Prints the 2D malloc array (map) element by element
 */

#include<stdio.h>

#include "printMap.h"

void printMap(char** map, int r, int c, int playerPosX, int playerPosY)
{
    int i, j, xLower, xUpper, yLower, yUpper;

    xLower = 0;
    xUpper = r;
    yLower = 0;        
    yUpper = c;

    /* Loops through 2D malloc array element-by-element */
    for(i = xLower; i < xUpper; i++)
    {
        for(j = yLower; j < yUpper; j++)
        {
            if(map[i][j] == ' ')
            {
                /* If nothing in meta data, print space */
                printf(" ");
            }
            else
            {
                /* Otherwise print meta data conterpart */
                printf("%c", map[i][j]);
            }            
        }
        printf("\n");
    }
}