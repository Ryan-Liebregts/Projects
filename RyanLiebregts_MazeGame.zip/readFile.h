#ifndef READFILE_H
#define READFILE_H

typedef struct
{
    int row;
    int col;
    int code;
}Data;

Data* readFile(FILE* file);

#endif