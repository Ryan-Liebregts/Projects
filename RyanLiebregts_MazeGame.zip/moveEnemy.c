/*
 * File: moveEnemy.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: Allows for the player movement in that map  
 */

#include<stdio.h>
#include<stdlib.h>

#include "moveEnemy.h"
#include "currentPos.h"
#include "LinkedList.h"

/* Note, x and y are inverted such that the
    x represents the vertical axis and,
    y represents the horizontal axis */


/*
 * Function: moveEnemy
 * Input: char** map, int r, int c, int enemyPosX, int enemyPosY, char pos, LinkedList* enemyList
 * Output: None
 * Purpose: Moves the enemy based on player location
 */
void moveEnemy(char** map, int r, int c, int enemyPosX, int enemyPosY, char pos, LinkedList* enemyList)
{
    int playerPosX, playerPosY, xDiff, yDiff, posX, posY;
    LinkedListNode* node;

    /* Deletes enemy form current position */
    map[enemyPosX][enemyPosY] = ' ';

    /* Undo */
    if(pos == 'u')
    {        
        /* Gets the location of the last move via the linked list */
        node = (enemyList -> tail) -> prev;
        
        /* Allocates the previous location to the next movement */
        posX = ((Position*)(node -> data)) -> x;
        posY = ((Position*)(node -> data)) -> y;
        
        /* Updates map */
        map[posX][posY] = '~';
    }
    /* Moves enemy according to player location */
    else if(pos == 'w' || pos == 's' || pos == 'a' || pos == 'd')
    {
        playerPosX = currentPos(map, r, c, 'x', 'P');
        playerPosY = currentPos(map, r, c, 'y', 'P');

        /* Calculates the difference between player location
            and enemy location */
        xDiff = playerPosX - enemyPosX;
        yDiff = playerPosY - enemyPosY;

        if(xDiff < 0)
        {
            xDiff = xDiff * -1;
        }
        if(yDiff < 0)
        {
            yDiff = yDiff * -1;
        }

        /* Moves enemy form current position */
        if(xDiff > yDiff)
        {
            if(playerPosX < enemyPosX) /* Moves up */
            {
                if(map[enemyPosX-1][enemyPosY] == 'o' || map[enemyPosX-1][enemyPosY] == '-')
                {
                    /* If walls/borders do not move */
                    map[enemyPosX][enemyPosY] = '~';
                }
                else
                {
                    /* Otherwise move up */
                    map[enemyPosX-1][enemyPosY] = '~';
                }
            }
            else if(playerPosX > enemyPosX) /* Moves down */
            {
                if(map[enemyPosX+1][enemyPosY] == 'o' || map[enemyPosX+1][enemyPosY] == '-')
                {
                    /* If walls/borders do not move */
                    map[enemyPosX][enemyPosY] = '~';
                }
                else
                {
                    /* Otherwise move down */
                    map[enemyPosX+1][enemyPosY] = '~';
                }
            }
        }
        else if(yDiff > xDiff)
        {
            if(playerPosY > enemyPosY) /* Moves right */
            {
                if(map[enemyPosX][enemyPosY+1] == 'o' || map[enemyPosX][enemyPosY+1] == '-')
                {
                    /* If walls/borders do not move */
                    map[enemyPosX][enemyPosY] = '~';
                }
                else
                {
                    /* Otherwise move right */
                    map[enemyPosX][enemyPosY+1] = '~';
                }
            }
            else if(playerPosY < enemyPosY) /* Moves down */
            {
                if(map[enemyPosX][enemyPosY-1] == 'o' || map[enemyPosX][enemyPosY-1] == '-')
                {
                    /* If walls/borders do not move */
                    map[enemyPosX][enemyPosY] = '~';
                }
                else
                {
                    /* Otherwise move down */
                    map[enemyPosX][enemyPosY-1] = '~';
                }
            }
        }
        else if(yDiff == xDiff)
        {
            if(playerPosY > enemyPosY) /* Moves right */
            {
                if(map[enemyPosX][enemyPosY+1] == 'o' || map[enemyPosX][enemyPosY+1] == '-')
                {
                    /* If walls/borders do not move */
                    map[enemyPosX][enemyPosY] = '~';
                }
                else
                {
                    /* Otherwise move right */
                    map[enemyPosX][enemyPosY+1] = '~';
                }
            }
            else if(playerPosY < enemyPosY) /* Moves down */
            {
                if(map[enemyPosX][enemyPosY-1] == 'o' || map[enemyPosX][enemyPosY-1] == '-')
                {
                    /* If walls/borders do not move */
                    map[enemyPosX][enemyPosY] = '~';
                }
                else
                {
                    /* Otherwise move down */
                    map[enemyPosX][enemyPosY-1] = '~';
                }
            }
        }
    }
    else
    {
        /* Otherwise reset player to front position in same location */
        map[enemyPosX][enemyPosY] = '~';
    }
}