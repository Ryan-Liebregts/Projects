/*
 * File: game.c
 * Author: Ryan Liebregts
 * Student ID: 20158316
 * Purpose: Creates the 2D malloc array (map) using the meta data input
 */

#include<stdio.h>
#include<stdlib.h>

#include "game.h"

/*
 * Function: createMap
 * Input: Data* metaD
 * Output: char** map
 * Purpose: Creates the game map using the meta data input
 */
char** createMap(Data* metaD)
{
    int i, j, x, y, ii = 1, r, c, numElements;
    char **map;
    /*Initial parameters assume 1 player and 1 goal */

    /* Formatting of map data is off due to location in text file */
    r = metaD[0].row; 
    c = metaD[0].col;
    numElements = metaD[0].code;

    /* Creates 2D malloc array */
    map = (char**)malloc(r * sizeof(char*));

	for (i = 0; i < r; ++i) 
    {
	    map[i] = (char*)malloc(c * sizeof(char));
    }

	for (i = 0; i < r; ++i) 
    {
		for (j = 0; j < c; ++j) 
        {
            map[i][j] = ' ';
            if((i == 0 && j == 0) || (i == 0 && j == c - 1) 
                || (i == r - 1 && j == 0) || (i == r - 1 && j == c - 1))
            {
                /* Adds the corners */
                map[i][j] = '#';
            }
            else if(j == 0 || j == c - 1)
            {
                /* Adds the left and right border */
                map[i][j] = '|';
            }
            else if(i == 0 || i == r - 1)
            {
                /* Adds the top and bottom border */
                map[i][j] = '-';
            }
		}
	}

    /* Adds the meta data */
    while(ii != numElements + 1)
    {
        if(metaD[ii].code == 0)
        {
            /* Adds the player */
            x = metaD[ii].row;
            y = metaD[ii].col;
            map[x][y] = '^';
        }
        if(metaD[ii].code == 1)
        {
            /* Adds the snake */
            x = metaD[ii].row;
            y = metaD[ii].col;
            map[x][y] = '~';
        }
        if(metaD[ii].code == 2)
        {
            /* Adds the goal/target */
            x = metaD[ii].row;
            y = metaD[ii].col;
            map[x][y] = 'x';
        }
        if(metaD[ii].code == 3)
        {
            /* Adds the wall */
            x = metaD[ii].row;
            y = metaD[ii].col;
            map[x][y] = 'o';
        }
        ii++;
    }

    return map;

}
